/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

/**
 *
 * @author Hp
 */
public class RubricsMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main m =new Main();
         m.setVisible(true);
        teachermain t = new teachermain();
       t.setVisible(true);
    }
    
}
