/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Hp
 */
public class RubricsMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
//        loadAdmin();
        loadStudentData();
        Main main = new Main();
        main.setVisible(true);
//        Teacher th = new Teacher();
//        th.setVisible(true);
    }

    public static void loadStudentData() throws IOException {
        Students s;
        FileInputStream inputStream = new FileInputStream(new File("StudentData.xlsx"));
        Workbook workbook = WorkbookFactory.create(inputStream);

        Sheet sheet = workbook.getSheetAt(0);
        int rowCount = sheet.getLastRowNum();
        for (int r = 0; r < rowCount + 1; r++) {
            s = new Students();
            s.setName(loadDataexcel(r, 1));
            s.setEmail(loadDataexcel(r, 2));
            s.setRegistrationNo(loadDataexcel(r, 3));
            s.setDepartment(loadDataexcel(r, 3));
            s.setSession(loadDataexcel(r, 4));
            Students.getobject().sList.add(s);

        }

    }

    public static String loadDataexcel(int row, int col) throws IOException {
        String value = null;
        Workbook wb = null;
        try {
            FileInputStream fis = new FileInputStream("StudentData.xlsx");
            wb = new XSSFWorkbook(fis);
        } catch (FileNotFoundException e) {

        }
        Sheet sheet = wb.getSheetAt(0);
        Row rows = sheet.getRow(row);
        Cell cell = rows.getCell(col);
        value = " " + cell.getStringCellValue();
        return value;
    }

    public static void loadAdmin() throws FileNotFoundException, IOException {
        FileReader fr = new FileReader("Admin.txt");
        BufferedReader br = new BufferedReader(fr);
        String line = br.readLine();
        while (line != null) {

            String[] strline = line.split(",");
            AdminData.getobject().setName(strline[0]);
            AdminData.getobject().setPassWord(strline[1]);
            AdminData.getobject().setPhone(strline[1]);
            AdminData.getobject().setEmail(strline[1]);
            AdminData.getobject().adminList.add(AdminData.getobject());
            AdminData.getobject().toString();

        }
        br.close();
        fr.close();
        fr = new FileReader("Teacher.txt");
        br = new BufferedReader(fr);
        line = br.readLine();
        while (line != null) {

            String[] strline = line.split(",");
            AdminData.getobject().setName(strline[0]);
            AdminData.getobject().setPassWord(strline[1]);
            AdminData.getobject().setPhone(strline[1]);
            AdminData.getobject().setEmail(strline[1]);
            AdminData.getobject().tList.add(AdminData.getobject());
            AdminData.getobject().toString();

        }
        br.close();
        fr.close();

    }

}
