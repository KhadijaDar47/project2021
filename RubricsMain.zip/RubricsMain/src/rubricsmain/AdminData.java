/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdminData {

    private String email;
    private String name;
    private String passWord;
    private String userName;
    private String phone;
    ArrayList<AdminData> tList = new ArrayList();
    ArrayList<AdminData> adminList = new ArrayList();
    private static AdminData obj;

    public static AdminData getobject() {
        if (obj == null) {
            obj = new AdminData();
        }
        return obj;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void saveAdminData(String file) {
        try {
            FileWriter fw = new FileWriter(file);
            
            
                fw.write(name + "," + passWord+ ","  +phone+ "," +email+"\n");
                fw.flush();
                fw.close();
                System.out.println(name + "," + passWord+ ","  +phone+ "," +email);
            
            JOptionPane.showMessageDialog(null, "DATA HAS BEEN SAVED");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "DATA HAS NOT BEEN SAVED");
        }
    }

    @Override
    public String toString() {
        return  email + ", name=" + name;
    }
    

}
