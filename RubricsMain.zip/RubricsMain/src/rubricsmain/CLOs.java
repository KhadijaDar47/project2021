/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class CLOs {

    private String clos;
    private String rubrics;
    ArrayList<CLOs> cList = new ArrayList();

    private static CLOs obj;

    public CLOs() {

    }

    public static CLOs getobject() {
        if (obj == null) {
            obj = new CLOs();
        }
        return obj;
    }

    public String getClos() {
        return clos;
    }

    public void setClos(String clos) {
        this.clos = clos;
    }

    public String getRubrics() {
        return rubrics;
    }

    public void setRubrics(String rubrics) {
        this.rubrics = rubrics;
    }

    public void adddata(CLOs c) {
        cList.add(c);
    }

    public ArrayList<CLOs> returnlist() {
        return cList;
    }

    public String displaydata() {
        String text;
        File file = new File("C:\Users\Hp\Documents\NetBeansProjects\RubricsMain\src\rubricsmain/CLOs.pdf");
        {
            try (PDDocument document = PDDocument.load(file)) {
                // Instantiate PDFTextStripper class
                PDFTextStripper pdfStripper = new PDFTextStripper();
                //Retrieving text from PDF document
                 text = pdfStripper.getText(document);
                System.out.println(text);
                return text;
                //Closing the document
            } catch (IOException e) {
                
            }
        }
        return " ";

    }
}
