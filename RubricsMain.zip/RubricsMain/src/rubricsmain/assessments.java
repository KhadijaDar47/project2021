/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

import java.util.ArrayList;

public class assessments  extends CLOs {
    private int quizNo;
    private int totalQuestion;
     private String clotype;
    private String assessmentsMarks;

    ArrayList<assessments> aList=new ArrayList();
     ArrayList<assessments> mList=new ArrayList();   
    private static assessments obj;
    public static assessments getobject()
    {
        if(obj==null)
        {
            obj= new assessments(); 
        }
       return obj;
    }
    public int getQuizNo() {
        return quizNo;
    }

    public void setQuizNo(int quizNo) {
        this.quizNo = quizNo;
    }

    public int getTotalQuestion() {
        return totalQuestion;
    }

    public void setTotalQuestion(int totalQuestion) {
        this.totalQuestion = totalQuestion;
    }
     
    public int marksChecker(int marks,int componentMarks)
    {
       
        return (marks/5)*componentMarks;
    }
    
    
    public String getClotype() {
        return clotype;
    }

    public void setClotype(String clotype) {
        this.clotype = clotype;
    }

    public String getAssessmentsMarks() {
        return assessmentsMarks;
    }

    public void setAssessmentsMarks(String assessmentsMarks) {
        this.assessmentsMarks = assessmentsMarks;
    }

    public ArrayList<assessments> getaList() {
        return aList;
    }

    public void setaList(ArrayList<assessments> aList) {
        this.aList = aList;
    }

    public ArrayList<assessments> getmList() {
        return mList;
    }

    public void setmList(ArrayList<assessments> mList) {
        this.mList = mList;
    }
   
   
    
    
    
    
    
}
