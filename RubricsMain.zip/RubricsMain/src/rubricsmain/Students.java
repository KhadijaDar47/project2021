/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricsmain;

import java.util.ArrayList;

public class Students {

  
    
    ArrayList<Students> sList = new ArrayList();
    private String name;
    private String registrationNo;
    private String email;
    private String department;
    private String session;
   ArrayList<Students> markList = new ArrayList();
    private String obMarks;
    private String componentMakrs;
    private String rubricMakrs;
    private String assessmentsNo;
    

    
    private static Students obj;

    public static Students getobject() {
        if (obj == null) {
            obj = new Students();
        }
        return obj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public void setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public String getComponentMakrs() {
        return componentMakrs;
    }

    public void setComponentMakrs(String componentMakrs) {
        this.componentMakrs = componentMakrs;
    }

    public String getRubricMakrs() {
        return rubricMakrs;
    }

    public void setRubricMakrs(String rubricMakrs) {
        this.rubricMakrs = rubricMakrs;
    }

    public String getAssessmentsNo() {
        return assessmentsNo;
    }

    public void setAssessmentsNo(String assessmentsNo) {
        this.assessmentsNo = assessmentsNo;
    }

    public String getObMarks() {
        return obMarks;
    }

    public void setObMarks(String obMarks) {
        this.obMarks = obMarks;
    }
    
    
    

    public ArrayList<Students> getMarks() {
        return markList;
    }

    public void setMarks(ArrayList<Students> marks) {
        this.markList = marks;
    }

    public void adddata(ArrayList<Students> sList) {
        this.sList = sList;

    }


    public ArrayList<Students> adddataList() {
        return sList;

    }

    @Override
    public String toString() {
        for (int i = 0; i <sList.size(); i++) {
            System.out.println("Name: ");
            System.out.println(sList.get(i).getName());
        }
        return " ";
    }
    

}
